//Ryan Wendling and Joshua Walker
//Assignment 1, CSCI 241 
//Takes in text files, deciphers and finds the real words that make up the text.

import java.util.*;
import java.io.*;
import java.lang.*;

public class Wordifier {

    // loadSentences
    // Preconditions:
    //    - textFilename is the name of a plaintext input file
    // Postconditions:
    //  - A LinkedList<String> object is returned that contains
    //    all of the tokens in the input file, in order
    // Notes:
    //  - If opening any file throws a FileNotFoundException, print to standard error:
    //        "Error: Unable to open file " + textFilename
    //        (where textFilename contains the name of the problem file)
    //      and then exit with value 1 (i.e. System.exit(1))       
	public static LinkedList<String> loadSentences( String textFilename ) {

        Scanner input = null;
        try {
            input = new Scanner(new File(textFilename));
        } catch (FileNotFoundException ex) {
            System.out.println("Error: File " + textFilename + " not found. Exiting program.");
            System.exit(1);
        }
        LinkedList<String> textList = new LinkedList<String>(); 	
        while (input.hasNext()) {
           textList.add(input.next());
        }
        return textList;                               
	}	
	
   
    // findNewWords
    // Preconditions:
    //    - bigramCounts maps bigrams to the number of times the bigram appears in the data
    //    - scores maps bigrams to its bigram product score 
    //    - countThreshold is a threshold on the counts
    //    - probabilityThreshold is a threshold on the bigram product score 
    // Postconditions:
    //    - A HashSet is created and returned, containing all bigrams that meet the following criteria
    //        1) the bigram is a key in bigramCounts
    //        2) the count of the bigram is >= countThreshold
    //        3) the score of the bigram is >= probabilityThreshold
    //      Formatting note: the returned HashSet should include a space between bigrams     
	public static HashSet<String> findNewWords( HashMap<String,Integer> bigramCounts, HashMap<String,Double> scores, int countThreshold, double probabilityThreshold ) {
	   
      HashSet<String> newWords = new HashSet<String>();
      for (String key : bigramCounts.keySet()) {
         if (bigramCounts.get(key) >= countThreshold && scores.get(key) >= probabilityThreshold) {
         newWords.add(key);
         }
      }
   return newWords;
   }      


    // resegment
    // Preconditions:
    //    - previousData is the LinkedList representation of the data
    //    - newWords is the HashSet containing the new words (after merging)
    // Postconditions:
    //    - A new LinkedList is returned, which contains the same information as
    //      previousData, but any pairs of words in the newWords set have been merged
    //      to a single entry (merge from left to right)
    //
    //      For example, if the previous linked list contained the following items:
    //         A B C D E F G H I
    //      and the newWords contained the entries "B C" and "G H", then the returned list would have 
    //         A BC D E F GH I
	public static LinkedList<String> resegment( LinkedList<String> previousData, HashSet<String> newWords ) {
	   
      //The new Linked List to be returned
      LinkedList<String> newData = new LinkedList<String>();
      ListIterator<String> dataItr = previousData.listIterator();
      //Iterate through the linked list of previous data
      String firstKey = dataItr.next(); 
      while(dataItr.hasNext()) {
         String secondKey = dataItr.next();
         String pair = firstKey + " " + secondKey;
         String pairNoSpace = firstKey + secondKey;  
         //If the bigram is contained in the new words, add it to the new data and skip the next unigram     
         if(newWords.contains(pair)) {
            newData.add(pairNoSpace);
            if (dataItr.hasNext()) {   
               firstKey = dataItr.next();
            }   
         //If it isn't in the new words, add just the current unigram and move on to check the next one
         } else {
            newData.add(firstKey);
            firstKey = secondKey;
         }         
      }        
	   return newData;      
   }


    // computeCounts
    // Preconditions:
    //    - data is the LinkedList representation of the data
    //    - bigramCounts is an empty HashMap that has already been created
    // Postconditions:
    //    - bigramCounts maps each bigram appearing in the data to the number of times it appears
	public static void computeCounts(LinkedList<String> data, HashMap<String,Integer> bigramCounts ) {
	   
       ListIterator<String> dataItr = data.listIterator();
       String firstKey = dataItr.next();
       while (dataItr.hasNext()) {
         String secondKey = dataItr.next();
         String keyValue = firstKey + " " + secondKey;
         // Populates bigramCounts hashmap with every unique bigram and the number of times it comes up.
         // Adds it to the HashMap if it isn't already in it, and adds 1 to its count if it is
         if(!bigramCounts.containsKey(keyValue)){
            bigramCounts.put(keyValue, 1);
         } else {
            int currentVal = bigramCounts.get(keyValue);
            bigramCounts.put(keyValue, currentVal+1);
         }
         firstKey = secondKey;
      }
	}


    // convertCountsToProbabilities 
    // Preconditions:
    //    - bigramCounts maps each bigram appearing in the data to the number of times it appears
    //    - bigramProbs is an empty HashMap that has already been created
    //    - leftUnigramProbs is an empty HashMap that has already been created
    //    - rightUnigramProbs is an empty HashMap that has already been created
    // Postconditions:
    //    - bigramProbs maps bigrams to their joint probability
    //        (where the joint probability of a bigram is the # times it appears over the total # bigrams)
    //    - leftUnigramProbs maps words in the first position to their "marginal probability"
    //    - rightUnigramProbs maps words in the second position to their "marginal probability"
	public static void convertCountsToProbabilities(HashMap<String,Integer> bigramCounts, HashMap<String,Double> bigramProbs, HashMap<String,Double> leftUnigramProbs, HashMap<String,Double> rightUnigramProbs ) {
	   
      //Find the total number of bigrams
      double sumBigrams = 0;
      for (double i : bigramCounts.values()) {
         sumBigrams += i;
      }
      //Loop through bigram counts grabbing the bigram as well as the left and right unigrams that make it up
      for (Map.Entry<String, Integer> entry : bigramCounts.entrySet()) {
         String bigram = entry.getKey();
         double value = entry.getValue();
         
         //Put the current bigram into the probability map and calculate its probability
         bigramProbs.put(bigram, (double)(value/sumBigrams));
         //Split the bigram into left and right unigrams
         String[] splitArr = bigram.split(" ");
         double currentVal = bigramCounts.get(bigram);
         //Add/modify the amount of each unigram to the appropriate list
         if(!leftUnigramProbs.containsKey(splitArr[0])){
            leftUnigramProbs.put(splitArr[0], currentVal);
         } else {
            leftUnigramProbs.put(splitArr[0], currentVal+leftUnigramProbs.get(splitArr[0]));
         }
         if(!rightUnigramProbs.containsKey(splitArr[1])){
            rightUnigramProbs.put(splitArr[1], currentVal);
         } else {
            rightUnigramProbs.put(splitArr[1], currentVal+rightUnigramProbs.get(splitArr[1]));
         }                    
      }
      
      //Calculate the probabilities of both left and right unigrams
      for (Map.Entry<String, Double> leftGramPair : leftUnigramProbs.entrySet()) {
         String leftGram = leftGramPair.getKey();
         double leftMarg = leftGramPair.getValue()/sumBigrams;
         leftUnigramProbs.put(leftGram, leftMarg);
      }
       for (Map.Entry<String, Double> rightGramPair : rightUnigramProbs.entrySet()) {
         String rightGram = rightGramPair.getKey();
         double rightMarg = rightGramPair.getValue()/sumBigrams;
         rightUnigramProbs.put(rightGram, rightMarg);
      }            
	}


    // getScores
    // Preconditions:
    //    - bigramProbs maps bigrams to to their joint probability
    //    - leftUnigramProbs maps words in the first position to their probability
    //    - rightUnigramProbs maps words in the first position to their probability
    // Postconditions:
    //    - A new HashMap is created and returned that maps bigrams to
    //      their "bigram product scores", defined to be P(w1|w2)P(w2|w1)
    //      The above product is equal to P(w1,w2)/sqrt(P_L(w1)*P_R(w2)), which 
    //      is the form you will want to use
	public static HashMap<String,Double> getScores( HashMap<String,Double> bigramProbs, HashMap<String,Double> leftUnigramProbs, HashMap<String,Double> rightUnigramProbs ) {
	   
      HashMap <String,Double> bigramScores = new HashMap <String,Double>();
      for (Map.Entry<String, Double> bigramPair : bigramProbs.entrySet()) {
         //Grab each bigram and its probability
         double bigramDoub = bigramPair.getValue();
         String bigram = bigramPair.getKey();
         //Split the bigram and grab the values for each unigram
         String[] bigramArr = bigram.split(" ");
         double leftVal = leftUnigramProbs.get(bigramArr[0]);
         double rightVal = rightUnigramProbs.get(bigramArr[1]);
         
         //calculate the bigram product for the current bigram
         double probScore = bigramDoub/(Math.sqrt((leftVal * rightVal)));       
         bigramScores.put(bigram, probScore); 
      }
      return bigramScores;      
	}


    // getVocabulary
    // Preconditions:
    //    - data is a LinkedList representation of the data
    // Postconditions:
    //    - A new HashMap is created and returned that maps words
    //      to the number of times they appear in the data
	public static HashMap<String,Integer> getVocabulary( LinkedList<String> data ) {
	  
      HashMap<String, Integer> wordMap = new HashMap<String, Integer>();
	   for(int i = 0; i <= data.size()-1; i++) {
         String keyValue = data.get(i);
         if(!wordMap.containsKey(keyValue)){
            wordMap.put(keyValue, 1);
         } else {
            int currentVal = wordMap.get(keyValue);
            wordMap.put(keyValue, currentVal+1);
         }
      }   
      return wordMap;            
   }


    // loadDictionary
    // Preconditions:
    //    - dictionaryFilename is the name of a dictionary file
    // Postconditions:
    //    - A new HashSet is created and returned that contains
    //      all unique words appearing in the dictionary
	public static HashSet<String> loadDictionary( String dictionaryFilename ) {
      
      HashSet<String> uniqueSet = new HashSet<String>();
        Scanner input = null;
        try {
            input = new Scanner(new File(dictionaryFilename));
        //Throw an error if the dictionary file cannot be read
        } catch (FileNotFoundException ex) {
            System.out.println("Error: File " + dictionaryFilename + " not found. Exiting program.");
            System.exit(1);
        }   
	   while (input.hasNext()) { 	
	      String currentWord = input.next();
         if (!uniqueSet.contains(currentWord)) {
            uniqueSet.add(currentWord);
         }
      }
   return uniqueSet;         
   }


    // incrementHashMap
    // Preconditions:
    //  - map is a non-null HashMap 
    //  - key is a key that may or may not be in map
    //  - amount is the amount that you would like to increment key's value by
    // Postconditions:
    //  - If key was already in map, map.get(key) returns amount more than it did before
    //  - If key was not in map, map.get(key) returns amount
	private static void incrementHashMap(HashMap<String,Integer> map,String key,int amount) {
		
      if( map.containsKey(key) ) {
			map.put(key,map.get(key)+amount);
		} else {
			map.put(key,amount);
		}
		return;
	}


    // printNumWordsDiscovered
    // Preconditions:
    //    - vocab maps words to the number of times they appear in the data
    //    - dictionary contains the words in the dictionary
    // Postconditions:
    //    - Prints each word in vocab that is also in dictionary, in sorted order (alphabetical, ascending)
    //        Also prints the counts for how many times each such word occurs
    //    - Prints the number of unique words in vocab that are also in dictionary 
    //    - Prints the total of words in vocab (weighted by their count) that are also in dictionary 
	// Notes:
    //    - See example output for formatting
	public static void printNumWordsDiscovered( HashMap<String,Integer> vocab, HashSet<String> dictionary ) {
      //The total number of tokens
      int bigramTokens = 0;
      //The total number of actual word tokens
      int actualTokens = 0;
      
      HashMap<String,Integer> filledDict = new HashMap<String, Integer>();
      // Creates a sorted array of the vocab
      Object[] vocabKey = new String[vocab.size()];
      vocabKey = vocab.keySet().toArray();
      for (int i = 0; i <= vocabKey.length-1; i++) {
         String conv = vocabKey[i].toString();           
	      if (dictionary.contains(vocabKey[i])) {
            filledDict.put(conv,vocab.get(vocabKey[i]));
         }     
         bigramTokens += vocab.get(vocabKey[i]); 
      }
      
      // Creates array of the vocab that was also in the dictionary, sorts it, and prints the name and count. 
      Object[] dictKey = new String[filledDict.size()];
      dictKey = filledDict.keySet().toArray();
      Arrays.sort(dictKey);
      for (int i = 0; i <= dictKey.length-1; i++) {
         String filledString = dictKey[i].toString();
         int filledInt = filledDict.get(filledString);
         actualTokens += filledInt;
         System.out.println("Discovered " + filledString + "(count " + filledInt + ")");
      }
      
      // Creates variables for the data to be printed         
      int uniqueWords = dictKey.length;
      int dictWords = dictionary.size();  
      double wordPercent = (((double)uniqueWords)/((double)dictWords)) * 100;
      double tokenPercent = (((double)actualTokens)/((double)bigramTokens)) * 100;
      
      System.out.println("");
      System.out.print("Discovered " + uniqueWords + " actual (unique) words out of " + dictWords + " dictionary words ("); 
      //Round the decimals to two places before printing
      System.out.printf("%.2f",wordPercent);
      System.out.print("%)"); 
      System.out.println("");
      
      System.out.print("Discovered " + actualTokens + " actual word tokens out of " + bigramTokens + " total tokens (");  
      System.out.printf("%.2f",tokenPercent);
      System.out.print("%)");
      System.out.println("");
   }
}