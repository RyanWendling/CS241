//Ryan Wendling
//Assignment 3, CSCI 241 
//README file


	The name of the first file I created was the Program3.java. This is the main file to run. It takes in a text file, gets the characters and frequencies from that, and creates a huffman Tree from the data. From there, it outputs the findings/codes to four different huf files in the output directory.
	The name of the second file I created was the fNode.java. This was a unique node class that held specific values like characters that were needed for the Huffman creation.
	The name of the third file I created was the minHeap.java. This is a custom minHeap class that is implemented using an array of fNodes. It has various methods to add, remove and maintain the heap.
	The other files that were made were the four output files emerson.huf, decl.huf, king.huf, and obama.huf. They have the findings from the huffman creation.


	The name of the main body file to be compiled was "Program3.java".


	Building the minHeap class was the most difficult part. It is kind of complicated to make the connection between the visual appearance of a tree and how it is implemented with an array. The associated code that went with that added to the difficulty as it was somewhat complex. The book had no algorithms for remove and exchange.
