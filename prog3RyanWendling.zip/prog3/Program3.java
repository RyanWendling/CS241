//Ryan Wendling
//Assignment 3, CSCI 241 
//Takes in text files, Finds the frequency of each character, 
//put it all in a sorted Min Heap via Huffman Codes and print out unique "code" for each character in output file.

import java.util.*;
import java.io.*;
import java.lang.*;

public class Program3 {


   public static int hBits;
        
	public static void main( String[] args ) {
   
      // Creates HashMap to hold characters and associated frequecies.
      // After, take in text file and loop through it to populate said HashMap 
      HashMap<Character, Integer> frequencyMap = new HashMap<Character, Integer>();
            
      System.out.println("enter file name");
      Scanner scanner = new Scanner(System.in);
      String fileName = scanner.nextLine();
      try {
         File file = new File(fileName);
            Scanner inFile = new Scanner(file);
            while (inFile.hasNext()) {
               String current = inFile.nextLine();
               for (int i = 0; i < current.length(); i++) {
                  char c = current.charAt(i);
                  if (!frequencyMap.containsKey(c)) {
                     frequencyMap.put(c, 1);
                  } else {
                     frequencyMap.put(c,frequencyMap.get(c) + 1);
                  }
               }         
            }
         inFile.close();   
      } catch (Exception error) {
         System.out.println(error);
      }
 
      // Create an ArrayList of nodes, where the nodes contain the data from the hashMap.       
      ArrayList <fNode> frequencyList = new ArrayList<fNode>();
      for (Map.Entry <Character, Integer> entry : frequencyMap.entrySet()) {
         char key = entry.getKey();
         int value = entry.getValue();      
         fNode charFreq = new fNode(key, value);
         frequencyList.add(charFreq);
      }
       
      // Convert ArrayList to Array, to be sorted with custom Comparator and inserted into newly created heap object.    
      fNode[] freqArr = new fNode[frequencyList.size()];
      freqArr = frequencyList.toArray(freqArr);     
      Arrays.sort(freqArr, new fNodeComparator());
      minHeap freqHeap = new minHeap(frequencyList.size() + 1);   
      for (int i = 0; i < frequencyList.size(); i++) {
         freqHeap.add(freqArr[i]);
      }
      freqHeap.add(freqArr[frequencyList.size() - 1]);
   
      // Make a Huffman Tree from the sorted Heap. Also, make a new output directory and .huf file       
      fNode finalTree = makeHuffman(freqHeap, frequencyList);
      String newFile = fileName.substring(0,fileName.indexOf("."));
      String newFileAll = newFile + ".huf";;
      String dir = "output";
      File directory = new File(dir);
      directory.mkdir();
      File f = new File(directory, newFileAll); 
      String code = new String();      
      genOrder(finalTree, code, f);
      int slowBits = finalTree.freq() * 8;
      
      // Add and print final statistics to created output file.
      try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(f, true)))) {
         out.println("Huffman Bits: " + (hBits));
         out.println("ASCII 8 digit Bits: " + slowBits);   
         out.println("Number of bits saved: " + (slowBits - hBits));
      } catch (IOException e) { 
         System.err.println("IOException: " + e.getMessage());
      }
      try{
         f.createNewFile();
      } catch (IOException err) { 
         System.err.println("IOException: " + err.getMessage());
      }   

   }
   
   
    // makeHuffman
    // Preconditions:
    //  - Has a sorted minimum heap and an arraylist, to use as the loop count.
    // Postconditions:
    //  - An fNode root is returned, attached is a Huffman Tree, containing leaves, nodes and larger frequencies near the root.
   public static fNode makeHuffman(minHeap inputQ, ArrayList <fNode> inputList) {
      
      int n = inputList.size();
      fNode lastlooper = new fNode();  
      char placeHolder = '\0';
      for (int i = 1; i < n-1 ; i++) {           
         fNode newNode = new fNode(placeHolder);
         newNode.left = inputQ.removeAt(1);
         newNode.right = inputQ.removeAt(1);     
         newNode.frequency = newNode.left.freq() + newNode.right.freq();
         inputQ.insert(newNode);
         lastlooper = newNode;
      }

      fNode finalNode = new fNode(placeHolder);
      finalNode.frequency = lastlooper.freq() + inputQ.get(1).freq();      
      if (lastlooper.freq() > inputQ.get(1).freq()){
         finalNode.right = lastlooper;
         finalNode.left = inputQ.get(1);
      } else {
         finalNode.right = inputQ.get(1);
         finalNode.left = lastlooper;   
      }   
   return finalNode;
   }
   
   
    // genOrder
    // Preconditions:
    //  - Has an fNode root with attached tree, to recursively travel through along with an empty String object, to create the specific code.
    // Postconditions:
    //  - A print statement with an associated character, frequency and unique identification huffman code.  
   public static void genOrder(fNode root, String s, File g) {
      
      if(root == null) return;
      genOrder (root.left, s + '0', g);
      if (root.letter() != '\0'){
         // Print the specific code for every character in a sorted order in created output file.
         try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(g, true)))) {
            out.println(root.letter() + "  " + s);
         } catch (IOException e) { 
            System.err.println("IOException: " + e.getMessage());
         }
         root.hCode = s;
         totalSaved(root);
      }
      genOrder (root.right, s + '1', g);
   }
   
   
    // totalSaved
    // Preconditions:
    //  - Has a specific leaf node.
    // Postconditions:
    //  - accumulates the specific node's bit cost to a total.  
   public static void totalSaved(fNode currentNode){

      String huffCode = currentNode.Code();
      hBits += (huffCode.length() * currentNode.freq());
   }         
}   