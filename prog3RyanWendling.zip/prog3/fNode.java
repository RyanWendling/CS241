//Ryan Wendling
//Assignment 3, CSCI 241 
//Custon node class that stores data values for character, frequency, children etc. 

import java.util.*;
import java.io.*;
import java.lang.*;

public class fNode{

    
    // Fields for the fNode class
    public char letter;
    public int frequency;
    public fNode left;
    public fNode right;
    public String hCode;
    
    
    //Construct a new fNode.
    fNode(char letter, int frequency) {    
        this.letter = letter; 
        this.frequency = frequency;
        this.left = null;
        this.right = null;
        this.hCode = null; 
    }
    
    
    //Construct a new fNode.
    fNode() {    
        this.letter = '\0'; 
        this.frequency = 0;
        this.left = null;
        this.right = null;
        this.hCode = null; 
    }
    
    
    //Construct a new fNode.    
    fNode(char letter) {    
        this.letter = letter; 
        this.frequency = 0;
        this.left = null;
        this.right = null;
        this.hCode = null; 
    }  
    
      
    //Construct a new fNode.
    fNode(char letter, int frequency, fNode leftChild, fNode rightChild, int position) {    
        this.letter = letter; 
        this.frequency = frequency;
        this.left = leftChild;
        this.right = rightChild;
        this.hCode = null; 
    }    
  
   
    //getter function   
    public fNode lefty() {
        return left; 
    }
    
    
    //getter function
    public fNode righty() {
        return right; 
    }
    
    
    //getter function  
    public char letter() {
        return letter; 
    }
    
    
    //getter function
    public int freq() {
        return frequency; 
    }
    
    
    //getter function
    public String Code() {
      return hCode;
    }     
}
   
   
    // fNodeComparator
    // Preconditions:
    //  - Have an amount of filled nodes ready to be compared.
    // Postconditions:
    //  - Gives priority to the less frequent node, if same frequency, tiebreaker goes to higher ASCII value.   
   class fNodeComparator implements Comparator<fNode> {

      @Override
      public int compare(fNode n1, fNode n2) {
         int ascii1 = (int) n1.letter();
         int ascii2 = (int) n2.letter();
         if(n1.freq() > n2.freq()) return 1;
         else if(n1.freq() < n2.freq()) return -1;
         else if (n1.freq() == n2.freq())
            if (ascii1 > ascii2) return 1;
            else return -1;     
         else return 0;
      }
   }    