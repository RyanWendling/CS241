//Ryan Wendling
//Assignment 3, CSCI 241 
//Custom minHeap class built to use fNodes and arrays
//put it all in a sorted Min Heap via Huffman Codes and print out unique "code" for each character in output file.

import java.util.*;
import java.io.*;
import java.lang.*;

public class minHeap<E> {
   
   
   private int size;
   private int endSize;
   private static final int FRONT = 1;
   private fNode[] heap;
   private static int left;
   private static int right;
   private static int largest;
   
    //Constructor
   public minHeap(int endSize) {
      this.endSize = endSize;
      this.size = 0;
      heap = new fNode[this.endSize + 1];
   } 
  
  
    // add
    // Preconditions:
    //  - an fNode and minHeap must be allready created.
    // Postconditions:
    //  - Simple commmand that puts fNode at the end of the Heap, fNodes would preferrable already be sorted.  
   public void add(fNode newNode) {
      heap[++size] = newNode;
   }    
   

    // removeAt
    // Preconditions:
    //  - an fNode and minHeap must be allready created.
    // Postconditions:
    //  - removes fNode from any location and re-minHeapifies as needed.  
   public fNode removeAt(int location) {
    if (size == 0) throw new IllegalArgumentException("Trying to delete from empty heap");
    if (location == size - 1) {
       --size;
    return heap[location];
    }
    fNode prevTop = heap[location];
    heap[location] = heap[size - 1];
    --size;
    minHeapify(heap, location);
    return prevTop;
    }    
    
    // minHeapify
    // Preconditions:
    //  - a minHeap must be allready created and populated.
    // Postconditions:
    //  - Goes up through the heap/tree and moves the lowest frequency fNodes to the top.  
   public void minHeapify(fNode[] a, int i){ 
      left = 2 * i;
      right = 2 * i + 1;
      if(left <= size && a[left].freq() < a[i].freq()){
         largest = left;
      }
      else{
         largest = i;
      }
        
      if(right <= size && a[right].freq() < a[largest].freq()){
         largest = right;
      }
      if(largest != i){
         exchange(i, largest);
         minHeapify(a, largest);
      }
   }


    // exchange
    // Preconditions:
    //  - an fNode and minHeap must be allready created.
    // Postconditions:
    //  - Basically swaps the location of two fNodes in their heap.   
   public void exchange(int i, int j){
      fNode f = heap[i];
      heap[i] = heap[j];
      heap[j] = f; 
   }                  


    // parent
    // Preconditions:
    //  - An fNode and minHeap must be allready created.
    // Postconditions:
    //  - Returns the location of the "parent" of node in question.        
   private final int parent(int i) {
      return i/2;
   }


    // left
    // Preconditions:
    //  - An fNode and minHeap must be allready created.
    // Postconditions:
    //  - Returns the location of the left child of node in question.
   private final int left(int i) {
      return 2 * i;
   }


    // right
    // Preconditions:
    //  - An fNode and minHeap must be allready created.
    // Postconditions:
    //  - Returns the location of the right child of node in question.
   private final int right(int i) {
      return 2 * i + 1;
   }  
      
      
    // left
    // Preconditions:
    //  - A minHeap must be allready created.
    // Postconditions:
    //  - Returns the list of nodes in a linear order.
    // Notes: Mostly useful for testing purposes. 
   public void printHeapOrder() {
      for (int i = 1; i < size; i++) {
         System.out.println("freq: " + heap[i].freq());
      }   
   }


    // insert
    // Preconditions:
    //  - An fNode and minHeap must be allready created.
    // Postconditions:
    //  - Slightly more complex add method that will add in the new fNode value and then minHeapify.   
   public void insert(fNode value) {
      heap[size] = value;
      minHeapify(heap, size);
      size++;
   }
    
   
   // Getter method  
   public fNode get(int i){
      return heap[i]; 
   }                              
}   
	